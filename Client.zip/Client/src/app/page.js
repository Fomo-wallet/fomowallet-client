"use client";
import About from "@/components/about";
import LandingPage from "@/components/landingpage";
import PlayGame from "@/components/playgame";
import React from "react";

const Page = () => {
  return (
    <>
      <LandingPage />
    </>
  );
};

export default Page;
